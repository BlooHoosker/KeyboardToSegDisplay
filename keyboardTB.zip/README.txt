- Simulační soubor obsahuje 256 řádků vygenerovaných vstupů a výstupů, 
aby se všechny vykonaly musí být nastavený dostatečně dlouhý simulační čas. 

-V souboru s testbenchem se musí nastavit cesta k souboru ps2input.txt proměnné SIMDATA aby testbench fungoval.

- Dále je v simulačním souboru na posledním řádku chyba, to je proto aby se zkontrolovalo že simulace určitě porovnává vstupy a výstupy.